package persistence.dao;

import domain.models.Medalla;

public interface MedallaDAO extends  GenericDAO<Medalla>{
}
