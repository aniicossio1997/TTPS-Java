package persistence.dao;

import domain.models.EstadoPublicacion;

public interface EstadoPublicacionDAO  extends GenericDAO<EstadoPublicacion>{
}
