package com.grupo20.ttpsspringboot.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ErrorDTO implements Serializable {

    private Integer status;
    private String message;
    private String error;

    public ErrorDTO(Integer status, String message, String error) {
        this.error = error;
        this.message = message;
        this.status = status;
    }
}
